#!/usr/bin/env python3
"""Ghép template.html + packs/*.json  ->  dist/index.html (1 file độc lập, mở bằng trình duyệt hoặc đưa lên hosting).
Dùng:  python3 build.py            (dựng bản đầy đủ)
Gói có tên bắt đầu bằng dấu gạch dưới (vd _nhap.json) sẽ bị bỏ qua."""
import json, glob, os, sys, hashlib
ROOT = os.path.dirname(os.path.abspath(__file__))
VERSION = '2.8.0'
SKILLS = {'fifty','double','shield','peek','skip','lucky','regen','hunter'}
ACCS = {'wind','flame','bubbles','star','crystal','drop','bolt','leaf','ring','flask'}
RARITY = ['C','R','SR','SSR']

def load_packs():
    out = []
    for f in sorted(glob.glob(os.path.join(ROOT, 'packs', '*.json'))):
        if os.path.basename(f).startswith('_'): continue
        with open(f, encoding='utf-8') as fh:
            p = json.load(fh)
        p['_file'] = os.path.basename(f)
        out.append(p)
    out.sort(key=lambda p: (p.get('order', 99), p.get('id', '')))
    return out

def validate(packs):
    errs, warns = [], []
    if not packs: errs.append('Không có gói dữ liệu nào trong thư mục packs/')
    ids, shorts, syms, slimes, cards = set(), set(), {}, set(), set()
    for p in packs:
        w = p.get('_file', '?')
        for k in ('id','short','name','sub','item','elements','cards'):
            if k not in p: errs.append(f'{w}: thiếu trường "{k}"')
        if errs and any(e.startswith(w) for e in errs): continue
        if p['id'] in ids: errs.append(f'{w}: trùng id gói "{p["id"]}"')
        if p['short'] in shorts: errs.append(f'{w}: trùng tên ngắn "{p["short"]}"')
        ids.add(p['id']); shorts.add(p['short'])
        mine = set()
        for e in p['elements']:
            for k in ('s','n','num','c','he','acc'):
                if k not in e: errs.append(f'{w}: nguyên tố {e.get("s","?")} thiếu "{k}"')
            if e.get('acc') not in ACCS: errs.append(f'{w}: {e.get("s")} có acc không hợp lệ "{e.get("acc")}" (chọn: {sorted(ACCS)})')
            if e['s'] in syms: errs.append(f'{w}: ký hiệu "{e["s"]}" đã dùng ở gói {syms[e["s"]]} (mỗi ký hiệu chỉ thuộc một gói)')
            syms[e['s']] = p['id']; mine.add(e['s'])
            rs = [s['r'] for s in e.get('slimes', [])]
            if sorted(rs, key=RARITY.index) != RARITY: warns.append(f'{w}: {e["s"]} nên có đủ 4 slime C,R,SR,SSR (hiện: {rs})')
            for s in e.get('slimes', []):
                if s['id'] in slimes: errs.append(f'{w}: trùng id slime "{s["id"]}"')
                slimes.add(s['id'])
                if s['r'] not in RARITY: errs.append(f'{w}: slime {s["id"]} có độ hiếm sai "{s["r"]}"')
                if s['k'] not in SKILLS: errs.append(f'{w}: slime {s["id"]} có kỹ năng sai "{s["k"]}" (chọn: {sorted(SKILLS)})')
        for i, b in enumerate(p.get('bosses', [])):
            if b['e'] not in mine: errs.append(f'{w}: boss #{i+1} thuộc nguyên tố "{b["e"]}" không có trong gói')
            for k in ('n','hp','atk','rw'):
                if k not in b: errs.append(f'{w}: boss #{i+1} thiếu "{k}"')
        imgs = p.get('images', {})
        neq = 0
        for c in p['cards']:
            if c['id'] in cards: errs.append(f'{w}: trùng id thẻ "{c["id"]}"')
            cards.add(c['id'])
            if c.get('t') not in ('f','i'): errs.append(f'{w}: thẻ {c["id"]} có t sai (chỉ "f" hoặc "i")')
            if not c.get('f', '').strip(): errs.append(f'{w}: thẻ {c["id"]} trống mặt trước')
            if c.get('t') == 'f':
                neq += 1
                if not c.get('b', '').strip(): warns.append(f'{w}: thẻ {c["id"]} chưa có mặt sau (sẽ bị bỏ khỏi luyện tập)')
            if c.get('m') and c['m'] not in imgs: errs.append(f'{w}: thẻ {c["id"]} dùng ảnh "{c["m"]}" không có trong images')
        if neq < 6: warns.append(f'{w}: chỉ có {neq} thẻ phương trình (nên từ 12 trở lên để trắc nghiệm có đủ đáp án nhiễu)')
    return errs, warns

def main():
    packs = load_packs()
    errs, warns = validate(packs)
    for w in warns: print('⚠ ', w)
    if errs:
        for e in errs: print('✗ ', e)
        sys.exit(1)
    for p in packs: p.pop('_file', None)
    data = {'app': 'EZChem', 'ver': VERSION, 'packs': packs}
    tpl = open(os.path.join(ROOT, 'template.html'), encoding='utf-8').read()
    en = open(os.path.join(ROOT, 'i18n', 'en.json'), encoding='utf-8').read()
    enc = open(os.path.join(ROOT, 'i18n', 'en_cards.json'), encoding='utf-8').read()
    html = tpl.replace('/*@ENC@*/{}', json.dumps(json.loads(enc), ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')).replace('/*@EN@*/[]', json.dumps(json.loads(en), ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')).replace('__DATA__', json.dumps(data, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/'))
    os.makedirs(os.path.join(ROOT, 'dist'), exist_ok=True)
    out = os.path.join(ROOT, 'dist', 'index.html')
    open(out, 'w', encoding='utf-8').write(html)
    import shutil
    pw = os.path.join(ROOT, 'pwa')
    if os.path.isdir(pw):
        for fn in os.listdir(pw):
            src = os.path.join(pw, fn); dst = os.path.join(ROOT, 'dist', fn)
            if fn == 'sw.js':
                open(dst, 'w', encoding='utf-8').write(open(src, encoding='utf-8').read().replace('__VER__', VERSION + '-' + hashlib.md5(html.encode('utf-8')).hexdigest()[:8]))
            else: shutil.copy(src, dst)
    kb = len(html.encode('utf-8')) // 1024
    print(f'✓ Đã dựng {out}  ({kb} KB)')
    for p in packs:
        n = sum(1 for c in p['cards'] if c['t'] == 'f')
        sl = sum(len(e.get('slimes', [])) for e in p['elements'])
        print(f'   - {p["short"]:<8} {p["name"]:<14} {n} thẻ · {len(p["elements"])} nguyên tố · {sl} slime · {len(p.get("bosses", []))} boss')
    if kb > 15000: print('⚠  File lớn hơn 15 MB: hãy giảm ảnh, vì trang đăng trên Claude giới hạn 16 MB.')

if __name__ == '__main__':
    main()
