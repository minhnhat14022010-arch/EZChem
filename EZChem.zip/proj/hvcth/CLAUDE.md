**v2.9 (nút cài đặt nổi):** chỉ còn một nút tròn nhỏ ⬇️ `#inst.finst` cố định ở góc phải dưới (nâng lên trên thanh tab trên điện thoại), bỏ nút ở thanh trên và màn hình khóa. Nếu không có `manifest.webmanifest` (chỉ tải mỗi index.html), `pwaFallback()` tự tạo manifest (blob, `start_url` tuyệt đối) và biểu tượng bằng canvas, nên vẫn cài được; đã kiểm bằng CDP `Page.getInstallabilityErrors` cả hai trường hợp.

**v2.9 (khóa chặt):** `act()` chặn mọi thao tác khi `S.v` là `gate`/`boot` trừ `gatego, spw, lang, install, theme, snd` (trước đây bấm logo EZChem → `t_home` vào thẳng ứng dụng mà không cần mật khẩu). Nút cài đặt luôn hiện trên http/https khi chưa cài (không phụ thuộc `beforeinstallprompt`; nếu chưa có sự kiện thì hiện hướng dẫn); thẻ manifest có `crossorigin="use-credentials"` để vẫn tải được khi Vercel bật Deployment Protection.

**v2.9 (nút cài đặt ở màn hình khóa):** `gate_v()` có thêm nút `.inst` (action `install`); `instBtn()` hiện/ẩn mọi nút `[data-act=install]` và được gọi cuối `view()`.

**v2.9 (PWA):** có thể cài đặt như ứng dụng và chạy ngoại tuyến. Thư mục `pwa/` (manifest.webmanifest, sw.js, biểu tượng) được `build.py` chép vào `dist/` (sw.js tự đổi phiên bản theo mã băm của trang). Template có thẻ manifest/theme-color, nút ⬇️ `#inst` (action `install`, dùng `beforeinstallprompt`; iOS hiện hướng dẫn) và đăng ký service worker chỉ khi mở qua http/https. Khi đưa lên hosting phải tải **toàn bộ thư mục dist/**, không chỉ index.html. Kiểm thử: 166 mục + thử thật bằng Chromium (manifest, service worker, tải lại khi ngoại tuyến).

**v2.8 (tách nhóm):** phương trình chỉ thuộc đúng nhóm chứa chúng. Mở nhóm trống → `setPack('none')` (`eq`/`C` rỗng) và `view()` hiển thị `emptyGroup()` cho mọi tab Học/Luyện tập/Thống kê/Kiến thức/Tra cứu, nên không còn lộ thẻ nhóm 15 sang nhóm khác. Kiểm thử: 166 mục.

**v2.8 (Kiến thức):** tab Quản lý đổi thành 📖 Kiến thức (`know()`): liệt kê toàn bộ phương trình của nhóm theo nguyên tố, có lọc nguyên tố/loại phản ứng, tìm kiếm; Quản lý thẻ & sao lưu vào qua nút trong trang này (`S.v='manage'`). Kiểm thử: 161 mục.

**v2.8 (độc lập):** mở file rời (không có Claude) thì app tự dùng kho lưu trên thiết bị (`localDb()`, khóa localStorage `ezc_db`, cùng giao diện với `CL.db`, cờ `CL.local`) nên Quản lý, thêm thẻ, nhập tệp, sao lưu JSON đều chạy; trong Claude vẫn dùng db của Claude. Chế độ độc lập không có AI (chỉ đọc nhanh), tải tệp qua Blob. Kiểm thử: 155 mục.

**v2.8:** tự khóa mỗi khi thoát ra rồi vào lại (`visibilitychange` → `lockNow()`, không còn nhớ phiên; đang mở hộp chọn tệp thì miễn qua `PICK`); sau mật khẩu luôn vào trang thư mục (`S.v='folders'`, `folders_v()`); nhóm trống vẫn mở được (`emptyGroup()`); thêm tài liệu một bước ngay trong nhóm (`importPanel(g)` → `imFile/imRun/imAI` → `MG.im_go`), nhóm trống tự được tạo khi nhập (`ensureGroupPack`, id `x-g<số nhóm>`). Tab Quản lý → AI chỉ còn “AI viết giải thích”. Kiểm thử: 149 mục.

**v2.7:** thêm tab Thống kê, ghi chú cá nhân (`PN`/`g15nt`), CSV, AI giải thích (`nt_ai`); smoke.js ⑪, 132 mục. Chuỗi UI mới phải thêm vào i18n/en.json.

# v2.6

Nâng cấp: **Cửa hàng orb** (hằng `SHOP`/`THEMES`: mở giao diện Đại dương/Rừng xanh/Hoàng hôn 30 orb, “Đóng băng chuỗi” 40 orb, tối đa 2, dùng tự động khi bỏ lỡ đúng 1 ngày – `streakNow()`/`touch()`); **tổng kết lượt ôn** (`S.ss`); **sao lưu tiến độ ra tệp JSON** (`bkfile`, nhập qua `#pbf`); **báo lỗi nhẹ nhàng** (window error → toast). Tiến độ lưu thêm `M.un` (giao diện đã mở) và `M.fz` (số lượt đóng băng). Kiểm thử: 120 kiểm tra.

# v2.5

Hoàn thiện ngôn ngữ: tự chọn Tiếng Việt/English theo trình duyệt lần đầu, nhớ lựa chọn; ghi chú trong thẻ có bản dịch ở `i18n/en_cards.json` (khóa = nguyên văn tiếng Việt của thẻ); lịch sử cập nhật có bản tiếng Anh. Giao diện responsive cho điện thoại (thanh trên gọn, thông báo nằm trên thanh điều hướng), máy tính bảng và máy tính (khung rộng hơn, thư mục 4 cột), vùng chạm ≥42px trên màn hình cảm ứng, viền focus cho bàn phím.

# v2.4

Đã **bỏ toàn bộ game** (săn orb, gacha, đấu boss) nhưng giữ hệ thống orb (kiếm từ ôn thẻ, nhiệm vụ, huy hiệu). Trang chính có **thư mục các nhóm nguyên tố** (nhóm 15 – VA chứa toàn bộ thẻ hiện có; các nhóm khác hiện “Sắp có”). **Hai ngôn ngữ**: bảng dịch ở `i18n/en.json` (cặp [tiếng Việt, English], build.py nhúng vào `/*@EN@*/`); mọi chuỗi giao diện tự dịch lúc hiển thị, nội dung thẻ do bạn nhập được giữ nguyên. Thêm chữ mới trên giao diện → thêm cặp dịch vào `i18n/en.json`. Kiểm thử: `node tests/smoke.js` (101 kiểm tra).

# ⚠️ v2.3 – BẢN CÁ NHÂN CÓ MẬT KHẨU

Từ v2.3 EZChem là bản **cá nhân** của giáo viên: **không còn đăng nhập, học sinh, lớp học, giao bài, đề thi, xếp hạng, thông báo**. Còn lại: flashcard, luyện tập, game (slime, boss, boss tuần), Quản lý (Flashcard, AI nhập thẻ, Cài đặt/sao lưu). Mọi phần mô tả đăng nhập/lớp học bên dưới là của v2.0–2.1 và đã bị gỡ. Bản gốc trước khi gỡ: template.v2.1 (xem lịch sử). Từ v2.3: **bỏ Kho tài liệu và Hồ sơ**; mở app phải nhập mật khẩu (băm PBKDF2-SHA256 310.000 vòng trong hằng `GATE` của template.html; muốn đổi mật khẩu thì sinh salt/băm mới, KHÔNG ghi mật khẩu rõ), tự khóa sau 30 phút, nút 🔒 để khóa ngay. Khi đăng: khai báo capabilities `sample`, `downloads`, `user` và `db` với rules `[{path:"",read:"view",write:"admin"},{path:"data/users/{self}",write:"interact"}]`. Kiểm thử: `node tests/smoke.js` (99 kiểm tra).

# EZChem – hướng dẫn cho Claude khi tiếp tục dự án

Ứng dụng web **một file** ôn tập Hóa vô cơ (flashcard + game slime + lớp học). Dữ liệu lớp nằm ở cơ sở dữ liệu `db` của trang Claude (artifact); mã nguồn nằm trong thư mục này. Người dùng là **giáo viên không chuyên kỹ thuật**: trả lời bằng tiếng Việt, ngắn gọn, nói rõ cái gì đã đổi.

## Quy trình mỗi lần sửa
1. Đọc `README.md` (cấu trúc, quy tắc gói dữ liệu, bảo mật) rồi sửa `template.html` và/hoặc `packs/*.json`.
2. `python3 build.py` → `dist/index.html` (tăng `VERSION` trong build.py khi đổi tính năng; ghi vào mảng `CHG` trong template).
3. `node tests/smoke.js` phải đạt toàn bộ (mô phỏng máy chủ có quy tắc quyền, nhiều thiết bị, AI giả lập). Thêm test cho tính năng mới.
4. Đăng lại **lên cùng liên kết cũ** để giữ dữ liệu lớp (Artifact `url` = liên kết cũ). Trước khi đăng: bỏ `<!doctype>`, `<html>`, `<head>`, `<body>`, `<meta>` khỏi `dist/index.html` (công cụ đăng tự bọc khung); giữ `<title>` và `<style>`.
5. Khi đăng, khai báo đủ capabilities (bỏ sót `sample` thì AI tắt, bỏ `downloads` thì không xuất CSV/sao lưu được):
```json
{"db":{"rules":[{"path":"","read":"view","write":"admin"},{"path":"reports","read":"view","write":"admin"},{"path":"reports/{self}","write":"interact"},{"path":"data/users/{self}","write":"interact"}]},
 "user":{"scopes":["profile"]},"downloads":true,"sample":{}}
```
(không khai báo `assets` nếu muốn chia sẻ ra ngoài tổ chức; khi đó chức năng đính kèm tệp tự ẩn).

## Bất biến – đừng phá
- **Không đổi id thẻ/slime đã có** (tiến độ học viên gắn theo id). `build.py` kiểm tra trùng id/ký hiệu.
- **Đăng nhập bắt buộc, không có chế độ khách.** Vai trò lấy từ bản ghi `roster/<tên>` (`r:'t'` = giáo viên), giáo viên còn phải là chủ/biên tập viên trang (`CL.adm`). Mật khẩu PBKDF2-SHA256 (`PW_IT`), có khóa tạm, tự đăng xuất (`IDLE_T/IDLE_S`). Học sinh không được ghi `roster`, `cfg`, `packs`, `docs`, `ann` (quy tắc db).
- Dữ liệu riêng tư của giáo viên (SĐT, phụ huynh, ghi chú) ở `data/users/<uid giáo viên>/prof_<tên>`; **không** đặt vào `roster` (học sinh đọc được).
- Cân bằng game (hằng số trong template): boss `bossCap(i)=20+8i` (sát thương tối đa mỗi đòn), `bossMin(i,n)` ép HP/ATK tối thiểu để **boss yếu nhất cần ≥10 câu đúng** dù đội mạnh nhất. Orb: săn orb ~10–18/phiên hoàn hảo, ôn thẻ chỉ tặng 1 orb mỗi 4 lần đúng. Đáp án nhiễu: `mkO` + `MUT` (biến thể gần đúng của đáp án thật).
- Dữ liệu lớp có thể sao lưu/khôi phục bằng JSON (Quản lý → Cài đặt) nên đổi cấu trúc db phải giữ tương thích hoặc viết bước chuyển đổi.

## Bản đồ `template.html`
- Đầu file: CSS (token màu `--bg --fg --acc …`, sáng/tối). Sau đó dữ liệu `D=__DATA__`, trạng thái học (`P,F,A,M,Z,SLV`), thẻ, quiz (`mkO`), săn orb (`hstart/hans`), gacha (`pull`), đấu trường (`bstart/bans`, `bossCap`).
- `CL` + `cloudInit/cloudSubs`: kết nối db; `boot()` → `login()/setup_v()/locked_v()`; `doLogin/doSetup/logout`.
- Giao diện lớp: `klass`, `acctv` (hồ sơ + avatar), `manage` → `mgHv` (học viên) / `mgSh` (chia sẻ) / `mgNd` (flashcard) / `mgAs` (giao bài) / `mgEx` (đề thi) / `mgAi` (AI) / `mgTd` / `mgTb` / `mgCd` (cài đặt, sao lưu, bảo mật). Hành động nằm trong đối tượng `MG`.
- AI: `askAI()` dùng capability `sample`; chỉ giáo viên thấy. Kết quả AI luôn qua bước xem trước trước khi ghi.

## Nhập dữ liệu từ phần mềm flashcard (khi người dùng đưa file)
- `.apkg/.colpkg/.txt/.tsv/.csv/.json`: `python3 tools/import_any.py <file> [--list] [--deck TÊN] -o tools/cards_x.csv`, rồi `tools/new_pack.py` (nhóm mới) hoặc nhập CSV vào nhóm có sẵn qua Quản lý → AI/Flashcard.
- `.sqlite` của Flippables: `tools/flippables_to_csv.py` (được `import_any.py` tự gọi).
- Luôn kiểm tra mẫu vài thẻ, báo số thẻ nhập/bỏ qua, không bịa nội dung hóa học.

## Sau này đóng gói thành ứng dụng riêng
`dist/index.html` chạy độc lập nhưng cần máy chủ thay cho `claude.use('db'|'user'|'sample')`. Giữ các lời gọi này sau một lớp mỏng (`CL.db`, `askAI`) để thay bằng Firebase/Supabase/API riêng; dữ liệu mang theo bằng bản sao lưu JSON.

## Mô-đun v2.1 (bài tập, đề thi, boss tuần, biệt danh)
- Khối `/* ===== v2.1 ... */` trong `template.html` (trước `addCards`). db: `asg/<id>`, `exams/<id>` (giáo viên ghi, học sinh chỉ đọc). Kết quả học sinh nằm trong `M.as` (bài tập), `M.ex` (đề thi), `M.wb`/`M.wk` (boss tuần), `M.nk`/`M.hu` (biệt danh/màu) và được gửi giáo viên qua `myReport()` (`as`, `ex`, `wb`, `nk`, `hu`).
- Boss tuần là boss tổng hợp `wbOf()` (`b.wk=1`, `i=-1`); `bstart(-1,b)`, `wbEnd`, trần sát thương `b.cap`. Không đổi chỉ số boss thường (`bossCap/bossMin`).
- Bài tập tự hoàn thành qua `chkAsg()` (được gọi sau `rate()` và khi nộp đề thi). Đề thi cố định danh sách id thẻ, đáp án nhiễu xáo ngẫu nhiên từng học sinh.
