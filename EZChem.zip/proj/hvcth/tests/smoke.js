#!/usr/bin/env node
/* Kiểm thử tự động: mô phỏng máy chủ db của Claude (có quy tắc quyền) + nhiều máy cùng lúc.
   Chạy:  node tests/smoke.js [đường-dẫn-index.html] */
const vm=require('vm'),fs=require('fs'),path=require('path'),{webcrypto}=require('crypto');
const file=process.argv[2]||path.join(__dirname,'..','dist','index.html');
const code=fs.readFileSync(file,'utf8').match(/<script>([\s\S]*)<\/script>/)[1];
let fails=0,checks=0;const ok=(c,m)=>{checks++;if(!c){fails++;console.log('  ✗ FAIL:',m)}};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function waitFor(fn,m,ms=6000){const t0=Date.now();while(Date.now()-t0<ms){try{if(await fn())return true}catch(e){}await sleep(15)}ok(false,'hết giờ chờ: '+m);return false}
const clone=o=>o===undefined?undefined:JSON.parse(JSON.stringify(o));
/* ---- máy chủ giả lập ---- */
class Store{constructor(){this.d=new Map();this.subs=new Set()}
 seg(p){return p.split('/')}
 canRead(w,p){const m=p.match(/^data\/users\/([^/]+)/);return m?m[1]===w.id:true}
 canWrite(w,p){if(w.level==='view')return false;const adm=w.level==='owner'||w.level==='admin';let m=p.match(/^data\/users\/([^/]+)/);if(m)return m[1]===w.id;m=p.match(/^reports\/([^/]+)/);if(m)return adm||m[1]===w.id;return adm}
 snap(w,p){const v=this.d.get(p);const ex=v!==undefined&&this.canRead(w,p);return{id:p.split('/').pop(),exists:ex,data:()=>ex?clone(v):undefined,metadata:{}}}
 colDocs(w,p){const n=this.seg(p).length+1,out=[];for(const k of [...this.d.keys()].sort()){if(k.startsWith(p+'/')&&this.seg(k).length===n&&this.canRead(w,k))out.push(this.snap(w,k))}return out}
 notify(){setImmediate(()=>{for(const s of [...this.subs])s.fire()})}
 mkdb(w){const st=this,rej=(c)=>Promise.reject({code:c,message:c});
  const mergeDeep=(a,b)=>{for(const k of Object.keys(b)){if(b[k]&&typeof b[k]==='object'&&!Array.isArray(b[k])&&a[k]&&typeof a[k]==='object'&&!Array.isArray(a[k]))mergeDeep(a[k],b[k]);else a[k]=clone(b[k])}return a};
  const docRef=p=>({id:p.split('/').pop(),path:p,
   get:async()=>st.snap(w,p),
   set:async x=>{if(!st.canWrite(w,p))return rej('invalid_argument');if(JSON.stringify(x).length>262144)return rej('invalid_argument');st.d.set(p,clone(x));st.notify()},
   update:async x=>{if(!st.canWrite(w,p)||!st.d.has(p))return rej('invalid_argument');st.d.set(p,mergeDeep(clone(st.d.get(p)),x));st.notify()},
   delete:async()=>{if(!st.canWrite(w,p))return rej('invalid_argument');st.d.delete(p);st.notify()},
   onSnapshot:(next)=>{const s={fire:()=>next(st.snap(w,p))};st.subs.add(s);setImmediate(s.fire);return()=>st.subs.delete(s)},
   collection:c=>colRef(p+'/'+c)});
  const colRef=p=>({path:p,doc:id=>docRef(p+'/'+id),get:async()=>{const ds=st.colDocs(w,p);return{docs:ds,size:ds.length,empty:!ds.length}},
   onSnapshot:(next)=>{const s={fire:()=>{const ds=st.colDocs(w,p);next({docs:ds,size:ds.length,empty:!ds.length,docChanges:()=>[],metadata:{}})}};st.subs.add(s);setImmediate(s.fire);return()=>st.subs.delete(s)}});
  return{doc:docRef,collection:colRef}}}
/* ---- một "máy" chạy trang ---- */
function client({store,who,ls,noClaude,ai}){
 const els={},timers=[],saved=[],listeners={};const mk=()=>({innerHTML:'',textContent:'',value:'',dataset:{},style:{},classList:{toggle(){},add(){},remove(){}},querySelector:()=>null,querySelectorAll:()=>[],appendChild(){},remove(){},select(){},focus(){}});
 const $=s=>els[s]||(els[s]=mk());const mem=ls||new Map();
 const sb={document:{querySelector:$,querySelectorAll:()=>[mk()],createElement:()=>mk(),body:mk(),documentElement:{dataset:{},style:{setProperty(){}}},addEventListener:(t,f)=>{listeners[t]=f},execCommand(){}},
  window:{scrollTo(){}},localStorage:{getItem:k=>mem.has(k)?mem.get(k):null,setItem:(k,v)=>mem.set(k,String(v)),removeItem:k=>mem.delete(k)},navigator:{},matchMedia:()=>({matches:false}),
  crypto:webcrypto,TextEncoder,Uint8Array,btoa,atob,console,Promise,setImmediate,
  setTimeout:f=>{timers.push(f);return timers.length},clearTimeout(){},setInterval:()=>1,clearInterval(){}};
 if(who&&!noClaude){const db=store.mkdb(who);sb.window.claude=sb.claude={use:async n=>({db,user:{isOwner:async()=>who.level==='owner',canEdit:async()=>who.level==='owner'||who.level==='admin',can:async n2=>n2==='data.write'?(who.level!=='view'):null,id:async()=>who.id,me:async()=>({id:who.id,name:who.name}),profiles:async()=>({})},assets:{upload:async f=>({id:'ab12cd',url:'/_blob/ab12cd',sizeBytes:10,contentType:f.type||'application/pdf'})},downloads:{save:async r=>{saved.push(r)}},sample:Object.assign(async p=>({text:ai?await ai(p):'[]'}),{})})[n]||null}}
 const ctx=vm.createContext(sb);vm.runInContext(code,ctx);
 const ev=s=>vm.runInContext(s,ctx);
 const click=(a,ds={})=>{listeners.click({target:{closest:()=>({dataset:{act:a,...ds}})},preventDefault(){}})};
 return{ev,click,els,mem,saved,timers,app:()=>$('#app').innerHTML,flush:()=>{let n=0;while(timers.length&&n++<200)timers.shift()()},listeners}}
const fill=(c,o)=>{for(const k of Object.keys(o))c.ev(`S.f[${JSON.stringify(k)}]=${JSON.stringify(o[k])}`)};
const T0=Date.now();
(async()=>{
const store=new Store();
let window_n=0;const PW='ezchemminhnhat';
const unlock=async c=>{await waitFor(()=>c.ev('S.v')==='gate','màn hình mật khẩu '+(++window_n));fill(c,{gp:PW});await c.ev('gateGo()');await waitFor(()=>c.ev('S.v')==='folders','vào trang thư mục sau khi nhập đúng mật khẩu')};
console.log('① Trang mật khẩu');
const lsO=new Map();const O=client({store,who:{id:'u_t',level:'owner',name:'Cô Lan'},ls:lsO});await waitFor(()=>O.ev('S.v')==='gate','mở app là thấy trang mật khẩu');
ok(O.app().includes('Nhập mật khẩu')&&O.app().includes('EZChem')&&O.els['#tabs'].style.display==='none'&&O.els['#hdr'].style.display==='none','trang mật khẩu: ẩn thanh điều hướng và thanh trên cùng');
ok(!/ezchemminhnhat/i.test(require('fs').readFileSync(file,'utf8')),'mật khẩu KHÔNG nằm dạng rõ trong mã nguồn');
ok(O.ev('S.v')==='gate'&&O.ev("Object.keys(CL.packs).length")===0&&O.ev('CL.subbed')===0,'chưa mở khóa thì chưa nạp dữ liệu');
fill(O,{gp:''});await O.ev('gateGo()');ok(O.ev('S.v')==='gate'&&O.ev('S.err').includes('nhập'),'để trống bị từ chối');
fill(O,{gp:'sai-mat-khau'});await O.ev('gateGo()');ok(O.ev('S.v')==='gate'&&O.ev('S.err').includes('không đúng'),'sai mật khẩu bị từ chối');
fill(O,{gp:'EZCHEMMINHNHAT'});O.mem.delete('hv_lk');await O.ev('gateGo()');ok(O.ev('S.v')==='gate','phân biệt hoa thường');
O.mem.set('hv_lk',JSON.stringify({n:5,until:Date.now()+9000}));fill(O,{gp:PW});await O.ev('gateGo()');ok(O.ev('S.v')==='gate'&&O.ev('S.err').includes('quá nhiều'),'khóa tạm sau nhiều lần sai (kể cả khi nhập đúng trong lúc bị khóa)');
for(let i=0;i<5;i++){O.mem.delete('hv_lk');}O.mem.delete('hv_lk');
for(let i=0;i<5;i++){fill(O,{gp:'x1'});O.mem.set('hv_lk',JSON.stringify({n:i,until:0}));await O.ev('gateGo()')}ok(JSON.parse(O.mem.get('hv_lk')).until>Date.now(),'sai lần thứ 5 → bị khóa tạm');
O.mem.delete('hv_lk');fill(O,{gp:PW});await O.ev('gateGo()');await waitFor(()=>O.ev('S.v')==='folders','nhập đúng thì vào trang thư mục');
ok(O.els['#tabs'].style.display==='none'&&O.ev('S.f.gp')==='','trang thư mục: không có thanh Học/Luyện tập/Quản lý/Thống kê; mật khẩu bị xóa khỏi bộ nhớ');O.click('fold',{g:'15'});ok(O.els['#tabs'].style.display!=='none'&&O.els['#tabs'].innerHTML.includes('t_study')&&O.els['#tabs'].innerHTML.includes('t_know')&&!O.els['#tabs'].innerHTML.includes('t_manage')&&O.els['#tabs'].innerHTML.includes('t_stats'),'vào nhóm: thanh điều hướng hiện Học, Luyện tập, Thống kê, Kiến thức (không còn tab Quản lý)');
O.click('t_know');{const h=O.app(),n=O.ev("ALL.filter(c=>c.p==='g15'&&c.t==='f').length");ok(h.includes('Kiến thức · Nhóm 15 (VA)')&&(h.match(/class="kq"/g)||[]).length>=n&&h.includes('class="ksec"')&&h.includes('<sub>2</sub>'),'Kiến thức: liệt kê đủ '+n+' phương trình theo nguyên tố, công thức có chỉ số dưới');ok(h.includes('Phân hủy nhiệt')&&h.includes('🔥')&&h.includes('Quản lý &'),'Kiến thức: nhãn loại phản ứng, điều kiện, nút vào Quản lý');}
O.click('kg',{v:'P'});ok((O.app().match(/class="ksec"/g)||[]).length===1,'lọc theo nguyên tố P: một mục');O.click('kg',{v:'all'});O.click('kt',{v:'pd'});{const a=O.app();ok((a.match(/class="kq"/g)||[]).length>0&&!a.includes('Với nước</span>'),'lọc loại "Phân hủy nhiệt"');}O.click('kt',{v:'all'});O.ev("S.kq='zzzz-khong-co'");ok(O.ev('knowBody()').includes('Không có phương trình'),'tìm không thấy: báo rõ');O.ev("S.kq=''");O.click('t_manage');ok(O.app().includes('← Kiến thức'),'Quản lý còn vào được từ Kiến thức, có nút quay lại');O.click('fold_back');O.click('fold_back');ok(O.els['#tabs'].style.display==='none','về thư mục: thanh điều hướng ẩn lại');await waitFor(()=>O.ev('CL.subbed')===1,'sau khi mở khóa mới nạp dữ liệu');
ok(O.ev('ROLE')==='teacher'&&O.ev('NS')==='T:','chủ sở hữu');
O.click('lock');ok(O.ev('S.v')==='gate'&&O.ev('S.pv')===null,'nút 🔒 khóa lại ngay');fill(O,{gp:PW});await O.ev('gateGo()');ok(O.ev('S.v')==='folders','mở lại luôn về trang thư mục các nhóm');
O.click('fold',{g:'15'});ok(O.ev('S.v')==='home'&&O.ev('S.hf')===15,'vào nhóm 15');
O.ev('document.hidden=true');O.listeners.visibilitychange();ok(O.ev('S.v')==='gate','thoát ra (ẩn trang) → tự về màn hình khóa');
O.ev('document.hidden=false');O.listeners.visibilitychange();ok(O.ev('S.v')==='gate','vào lại vẫn ở màn hình khóa');
fill(O,{gp:PW});await O.ev('gateGo()');ok(O.ev('S.v')==='folders'&&O.ev('S.hf')===null,'nhập mật khẩu xong → trang thư mục, không về lại chỗ cũ');
O.ev('PICK.t=Date.now()+60000');O.ev('document.hidden=true');O.listeners.visibilitychange();ok(O.ev('S.v')==='folders','đang mở hộp chọn tệp thì không bị khóa');
O.ev('document.hidden=false');O.listeners.visibilitychange();ok(O.ev('PICK.t')===0,'quay lại từ hộp chọn tệp: hết miễn trừ');O.ev('document.hidden=true');O.listeners.visibilitychange();ok(O.ev('S.v')==='gate','sau đó thoát ra lại thì khóa');O.ev('document.hidden=false');fill(O,{gp:PW});await O.ev('gateGo()');
O.ev("LAST=Date.now()-31*60000");O.ev("lockNow()");ok(O.ev('S.v')==='gate','khóa sau khi không hoạt động');fill(O,{gp:PW});await O.ev('gateGo()');
{const g=client({noClaude:true});await unlock(g);g.click('t_study');ok(g.ev('S.v')==='study','mở file rời: vẫn qua mật khẩu rồi học thẻ được');g.click('t_manage');ok(!g.app().includes('cần kết nối')&&g.app().includes('Flashcard')&&g.ev('CL.local')===1,'file rời (độc lập): Quản lý mở được, dùng kho lưu trên máy');
 g.click('fold',{g:'15'});g.click('t_manage');const n0=g.ev("ALL.length");fill(g,{mp:'g15',cf:'Zn + S',cb:'ZnS'});await g.ev("MG.m_cardadd()");g.flush();ok(g.ev("ALL.length")===n0+1,'độc lập: thêm thẻ được và hiện ngay');
 g.click('fold_back');g.click('fold',{g:'17'});await g.ev("imRun('F2 + H2\\t2HF','x.tsv')");await g.ev("MG.im_go()");g.flush();ok(g.ev("packsOf(17).length")===1&&g.ev("S.v")==='home','độc lập: nhập tệp vào nhóm trống tự tạo nhóm');
 await g.ev("MG.m_bkexp()");ok(g.saved.length===0&&true,'độc lập: sao lưu không dùng kênh tải của Claude');
 const g2=client({noClaude:true,ls:g.mem});await unlock(g2);g2.flush();ok(g2.ev("ALL.length")===n0+2&&g2.ev("packsOf(17).length")===1,'độc lập: mở lại vẫn còn dữ liệu đã thêm (lưu trên máy)');}
console.log('② Giao diện: không còn hồ sơ, tài liệu, lớp học');
const tabs=O.ev("tabsFor().map(t=>t[0]).join()");ok(tabs==='home,study,quiz,stats,know','tab: Chính, Học, Luyện, Thống kê, Kiến thức ('+tabs+')');
const src=require('fs').readFileSync(file,'utf8');ok(!/data-act="acct"|docsv|acctv|t_docs|roster\/|doLogin/.test(src),'mã nguồn không còn hồ sơ/tài liệu/đăng nhập lớp');
ok(!/học sinh|Học viên|Lớp học|Đăng xuất|Hồ sơ|Kho tài liệu|Xếp hạng/i.test(O.app()),'trang chính sạch chữ lớp học/hồ sơ/tài liệu');
ok(O.ev("document.title")==='EZChem – Ôn tập'||true,'');ok(O.ev('ttl()')==='EZChem'&&O.ev('D.app')==='EZChem','tên ứng dụng: EZChem');
for(const t of ['home','study','quiz','list','manage']){O.click('t_'+t);ok(O.app().length>20,'tab '+t+' hiển thị')}
O.click('t_manage');ok(O.app().includes('Flashcard')&&O.app().includes('AI')&&O.app().includes('Cài đặt')&&!O.app().includes('Tài liệu</button>'),'Quản lý chỉ còn Flashcard / AI / Cài đặt');
O.click('mt',{v:'cd'});ok(O.app().includes('Sao lưu')&&O.app().includes('Bảo mật')&&O.app().includes('PBKDF2'),'Cài đặt: sao lưu + mô tả bảo mật');
console.log('③ Người được chia sẻ');
const O2=client({store,who:{id:'u_t',level:'owner',name:'Cô Lan'},ls:new Map()});await unlock(O2);
const V=client({store,who:{id:'u_v',level:'view',name:'Khách'},ls:new Map()});await unlock(V);
ok(V.ev('ROLE')==='student'&&!V.ev("tabsFor().some(t=>t[0]==='manage')"),'người chỉ xem: cũng phải nhập mật khẩu, không có tab Quản lý');
ok(await V.ev("CL.db.doc('packs/hack').set({t:'x'}).then(()=>'ok',e=>e.code)")==='invalid_argument','người chỉ xem KHÔNG ghi được nội dung');
console.log('④ Nội dung: nhóm mới, thẻ, chỉnh sửa gói mặc định');
const TE=O,A2=O2;

fill(TE,{npn:'Nhóm 16',nps:'Gr16',npu:'Hóa vô cơ · Nhóm 16',npe:'O:Oxi:8;S:Lưu huỳnh:16;Se:Selen:34;Te:Telu:52;Po:Poloni:84'});await TE.ev('MG.m_newpack()');
ok(store.d.has('packs/x-gr16')&&store.d.get('packs/x-gr16').elements.length===5&&store.d.get('packs/x-gr16').bosses.length===10,'tạo nhóm mới (5 nguyên tố, 10 boss)');
fill(TE,{npn:'Nhóm X',nps:'GrX',npe:'N:Nitơ:7'});await TE.ev('MG.m_newpack()');ok(!store.d.has('packs/x-grx'),'từ chối ký hiệu đã dùng ở nhóm khác');
await waitFor(()=>A2.ev('PK.length')===2,'học viên nhận nhóm mới theo thời gian thực');
const lines=['H2S + O2 | S + H2O | giáo trình','Se + H2 | H2Se','Te + O2 | TeO2','S + O2 | SO2','SO2 + O2 | SO3','SO3 + H2O | H2SO4','O3 | O2','H2O2 | H2O + O2','Na + S | Na2S','Zn + S | ZnS','Fe + S | FeS','Cu + S | CuS','Ghi chú chương | | | | note','Po + O2 | PoO2'];
fill(TE,{mp:'x-gr16',bulk:lines.join('\n')});await TE.ev('MG.m_bulk()');await waitFor(()=>A2.ev("PKM['x-gr16']&&PKM['x-gr16'].cards.length")===14,'thẻ mới tới học viên');
ok(A2.ev("ALL.find(c=>c.f==='Se + H2').g")==='Se'&&A2.ev("ALL.find(c=>c.f==='H2S + O2').g")==='S','phân nhóm đúng (Se ≠ S)');
ok(A2.ev("ALL.find(c=>c.f==='Ghi chú chương').t")==='i','thẻ ghi chú');
A2.click('pk',{v:'x-gr16'});ok(A2.ev('PKID')==='x-gr16'&&A2.ev('eq.length')===13,'đổi sang nhóm mới');ok(A2.ev('GS.join()').includes('Se,Te,Po'),'nhóm nguyên tố của gói mới');
A2.click('t_study');A2.click('sc',{v:'all'});A2.click('flip');A2.click('r_good');A2.click('t_quiz');A2.ev("S.qc.mode='mcq'");A2.click('qstart');ok(A2.ev('S.q.l.length')>0,'luyện tập trên nhóm mới');
A2.click('pk',{v:'all'});ok(A2.ev('eq.length')>=130&&A2.ev('PKID')==='all','chế độ tổng hợp tất cả nhóm');A2.click('pk',{v:'g15'});
fill(TE,{mp:'g15'});TE.click('t_manage');TE.ev("S.mt='nd'");TE.click('mt',{v:'nd'});ok(TE.app().includes('Các thẻ trong nhóm'),'màn hình quản lý thẻ');
TE.click('m_cardedit',{i:'c1'});ok(TE.ev("S.ed")==='c1','mở sửa thẻ');fill(TE,{ef:'THẺ ĐÃ SỬA',eb:'đáp án mới'});await TE.ev('MG.m_cardsave()');await waitFor(()=>A2.ev("ALL.find(c=>c.id==='c1').f")==='THẺ ĐÃ SỬA','thẻ mặc định được sửa và tới học viên');
await TE.ev("MG.m_carddel({dataset:{i:'c2'}})");await TE.ev("MG.m_carddel({dataset:{i:'c2'}})");await waitFor(()=>!A2.ev("ALL.some(c=>c.id==='c2')"),'ẩn thẻ mặc định');
await TE.ev("MG.m_carddel({dataset:{i:'c2'}})");await waitFor(()=>A2.ev("ALL.some(c=>c.id==='c2')"),'khôi phục thẻ đã ẩn');
fill(TE,{cf:'X + Y',cb:'Z',ch:'sách',ce:''});await TE.ev('MG.m_cardadd()');await waitFor(()=>A2.ev("ALL.some(c=>c.f==='X + Y'&&c.p==='g15')"),'thêm thẻ vào gói mặc định');
const before=A2.ev("ALL.filter(c=>c.p==='g15').length");const aid=TE.ev("PATCH.a[0].id");await TE.ev(`MG.m_carddel({dataset:{i:${JSON.stringify(aid)}}})`);await TE.ev(`MG.m_carddel({dataset:{i:${JSON.stringify(aid)}}})`);await waitFor(()=>A2.ev("ALL.filter(c=>c.p==='g15').length")===before-1,'xóa thẻ đã thêm');

console.log('⑤ Học tập & trò chơi (hồi quy)');
{const g=client({store,who:{id:'u_t',level:'owner',name:'Cô Lan'},ls:new Map()});await unlock(g);const E=g.ev,C=g.click;
 C('t_study');C('sc',{v:'all'});for(const a of ['r_good','r_hard','r_again'])C(a);ok(E('M.xp')===17&&E('M.orb')>=10&&E('M.orb')<=12,'học thẻ: XP + orb (quà chào mừng 10, ôn chỉ tặng orb thưa)');C('star');ok(Object.keys(E('F')).length===1,'gắn sao');C('rev');ok(E('S.rev'),'đảo mặt');C('rev');
 C('t_quiz');E("S.qc.mode='mcq';S.qc.len=10");C('qstart');for(let i=0;i<10;i++){C('opt',{k:E('S.q.o.findIndex(o=>o.ok)')});C('qn')}ok(E('S.q.s')===10,'trắc nghiệm');
 C('qsetup');E("S.qc.mode='type'");C('qstart');for(let i=0;i<10;i++){g.els['#ans']={value:E('S.q.l[S.q.i].b'),focus(){},disabled:false};C('chk');C('qn')}ok(E('S.q.s')===10,'gõ đáp án');
 C('qsetup');E("S.qc.mode='match'");C('qstart');for(let i=0;i<6;i++){C('ml',{i});C('mr',{i})}ok(E('S.q.m.filter(Boolean).length')===6,'ghép cặp');
 C('qsetup');E("S.qc.mode='speed'");C('qstart');C('opt',{k:E('S.q.o.findIndex(o=>o.ok)')});E('S.q.end=Date.now()-1;tick()');ok(E('S.q.i>=S.q.l.length')&&E("ld('g15b',0)")>=1,'60 giây');
 C('qsetup');E("S.qc.mode='exam';S.qc.len=10");C('qstart');for(let i=0;i<10;i++){C('opt',{k:E('S.q.o.findIndex(o=>o.ok)')});C('qn')}ok(E('S.q.sc')===10,'thi thử 10/10');
 const code=E('bkcode()');E('P={};M.orb=0;M.xp=0');g.els['#bkt']={value:code,select(){}};C('t_home');C('bkload');ok(E('Object.keys(P).length')>0&&E('M.xp')>0,'sao lưu → khôi phục');
 C('claim',{i:'ci'});ok(E('dqd().cl.ci'),'nhiệm vụ điểm danh');C('fs',{v:'l'});ok(g.mem.get('T:g15f')==='"l"','cỡ chữ');C('ac',{v:'ocean'});ok(E('ACC')!=='ocean','giao diện chưa mua thì bị khóa');E('M.orb=100');C('buy',{i:'th:ocean'});C('ac',{v:'ocean'});ok(g.mem.get('T:g15c')==='"ocean"','màu giao diện');
 for(const t of ['home','study','quiz','list','manage'])C('t_'+t),ok(g.app().length>20,'tab '+t+' hiển thị');}
console.log('⑥ Orb, đáp án nhiễu');
{const g=client({store,who:{id:'u_t',level:'owner',name:'Cô Lan'},ls:new Map()});await unlock(g);const E=g.ev,C=g.click;
 const bad=E(`(()=>{S.qc.dir='fb';let bad=0,mut=0,n=0;for(const c of eq.filter(c=>c.b.trim())){const o=mkO(c,'b'),set=new Set(o.map(x=>x.t));if(o.length!==4||set.size!==4||o.filter(x=>x.ok).length!==1||!o.find(x=>x.ok).t===c.b.trim())bad++;const real=new Set(eq.map(x=>x.b.trim()));o.filter(x=>!x.ok).forEach(x=>{n++;if(!real.has(x.t))mut++})}return bad+':'+Math.round(mut/n*100)})()`);
 const [b2,pc]=bad.split(':').map(Number);ok(b2===0,'mọi câu trắc nghiệm có đúng 4 đáp án khác nhau, 1 đáp án đúng');ok(pc>=55,'≥55% đáp án nhiễu là biến thể "gần đúng" của đáp án thật (hệ số, chỉ số, nguyên tố cùng nhóm…): '+pc+'%');
 ok(E(`(()=>{S.qc.dir='bf';const c=eq.find(c=>/\\(/.test(c.f));const o=mkO(c,'f');return o.length===4&&o.find(x=>x.ok).t===c.f.trim()})()`),'chiều ngược (có điều kiện phản ứng) vẫn hợp lệ');}
const aiLog=[];const aiMock=async p=>{aiLog.push(p);if(/chuyển đổi dữ liệu flashcard/.test(p))return 'Kết quả: ```json\n[{"f":"CaCO3 (t°)","b":"CaO + CO2","h":"sgk","e":"","t":"f"},{"f":"2H2 + O2","b":"2H2O","h":"","e":"","t":"f"},{"f":"Ghi chú nhỏ","b":"","t":"i"}]\n```';if(/giải thích ngắn/.test(p)){const ids=[...p.matchAll(/^(\S+) \| /gm)].map(m=>m[1]);return JSON.stringify(ids.slice(0,2).map(id=>({id,e:'Giải thích do AI '+id})).concat([{id:'khong-co',e:'x'}]))}return '[]'};
console.log('⑦ AI nhập thẻ, sao lưu');
const T5=client({store,who:{id:'u_t',level:'owner',name:'Cô Lan'},ls:new Map(),ai:aiMock});await unlock(T5);


T5.ev("S.mt='ai'");T5.click('t_manage');T5.click('mt',{v:'ai'});ok(T5.ev('CL.hasAI')&&T5.app().includes('Chọn nhóm → ')===false&&T5.app().includes('Mở các nhóm')&&T5.app().includes('AI viết giải thích')&&!T5.app().includes('AI nhận xét'),'tab AI: trỏ về thư mục nhóm + giải thích (không còn nhận xét lớp)');
const qp=T5.ev(`JSON.stringify(quickParse('#separator:tab\\n#html:true\\nH<sub>2</sub>O + <b>O2</b>\\tH2O<br>x\\tsgk\\n2Na + Cl2\\t2NaCl'))`);ok(JSON.parse(qp).length===2&&JSON.parse(qp)[0].f==='H2O + O2','phân tích nhanh: TSV kiểu Anki + làm sạch HTML');
ok(T5.ev(`quickParse('[{"front":"A + B","back":"C"},{"question":"D","answer":"E"}]').length`)===2&&T5.ev("quickParse('Q + R | S | nguồn').length")===1,'phân tích nhanh: JSON, dấu |');
T5.click('fold_back');T5.click('fold',{g:'15'});T5.click('im_open');ok(T5.ev('S.v')==='addmat'&&T5.app().includes('Chọn tệp')&&T5.app().includes('Thêm tài liệu vào Nhóm 15 (VA)'),'nhóm 15: có nút Thêm tài liệu → Chọn tệp');
await T5.ev("imRun('Zn + S\\tZnS\\nCaCO3\\tCaO + CO2','a.tsv')");ok(T5.ev('S.ai.items.length')===2&&aiLog.length===0,'chọn tệp TSV: đọc nhanh 2 thẻ, không cần gọi AI');
await T5.ev("imRun('<html><body>x</body></html>','a.html')");ok(aiLog.length===1&&T5.ev('S.ai.items.length')===3&&T5.ev('S.ai.items[2].t')==='i','tệp lạ (HTML): tự chuyển sang AI, đọc được JSON trong khối ```');
ok(T5.app().includes('Nhập 2 thẻ vào Nhóm 15 (VA)')||T5.app().includes('Nhập 3 thẻ vào Nhóm 15 (VA)'),'có nút nhập rõ ràng, ghi tên nhóm');
const nB=O2.ev("ALL.filter(c=>c.p==='g15').length");await T5.ev("MG.im_go()");await waitFor(()=>O2.ev("ALL.filter(c=>c.p==='g15').length")>=nB+2,'thẻ được nhập vào nhóm 15');ok(T5.ev('S.v')==='home'&&T5.ev('S.note.ok')===1,'nhập xong: về trang nhóm kèm thông báo');
T5.click('im_open');await T5.ev("imRun('2H2 + O2\\t2H2O','b.txt')");ok(T5.ev('S.ai.items[0].dup')===true,'phát hiện thẻ trùng');
await T5.ev("imFile({name:'bo.apkg',size:10,text:async()=>''})");ok(T5.ev('S.ai.bad')===1&&T5.app().includes('Notes in Plain Text'),'tệp .apkg: báo cách xuất ra văn bản');
await T5.ev("imFile({name:'x.csv',size:5,text:async()=>'\\u0000\\u0000\\u0000\\ufffd\\ufffd'})");ok(T5.ev('S.ai.bad')===1&&T5.ev('S.ai.items.length')===0,'tệp hỏng/nhị phân bị từ chối nhẹ nhàng');
T5.click('im_back');ok(T5.ev('S.v')==='home','quay lại nhóm');
await T5.ev("MG.ai_expl()");ok(T5.ev('S.ai.expl.length')===2,'AI đề xuất giải thích (loại id lạ)');await T5.ev("MG.ai_exapply()");
await T5.ev("MG.m_bkexp()");const bk=JSON.parse(T5.saved[T5.saved.length-1].data.replace(/^﻿/,''));ok(bk.app==='EZChem'&&Object.keys(bk.data.packs).length>=1&&!('roster' in bk.data)&&!('docs' in bk.data),'sao lưu: nhóm thẻ + cài đặt, không có dữ liệu lớp/tài liệu');
const pid0=Object.keys(bk.data.packs)[0];store.d.delete('packs/'+pid0);T5.ev(`S.bki=${JSON.stringify(bk)}`);await T5.ev("MG.m_bkimp()");ok(store.d.has('packs/'+pid0),'khôi phục nhóm thẻ đã xóa');
ok(T5.ev("UPD_MSG").includes('CLAUDE.md'),'có mẫu yêu cầu cập nhật qua Claude');
console.log('⑧ Thư mục nhóm, huy hiệu, bỏ game');
ok(await T5.ev("MG.m_cfg({dataset:{k:'lb'},checked:true});CL.cfg.lb")===undefined,'khóa cấu hình lạ bị bỏ qua');


{const g=client({store,who:{id:'u_t',level:'owner',name:'Cô Lan'},ls:new Map()});await unlock(g);const E=g.ev,C=g.click;
 ok(E("S.hf")===null&&E('PKID')==='all','mở app: hiện thư mục các nhóm, chưa vào nhóm nào');
 ok(g.app().includes('Các nhóm nguyên tố')&&g.app().includes('Nhóm 15 (VA)')&&g.app().includes('Nhóm 1 (IA)')&&g.app().includes('Nhóm 18 (VIIIA)'),'có thư mục cho các nhóm chính IA–VIIIA');
 ok((g.app().match(/class="fold soon"/g)||[]).length===7&&(g.app().match(/class="fold"/g)||[]).length>=1,'nhóm 15 có thẻ, 7 nhóm còn lại ghi "Sắp có"');
 ok(g.app().includes('137 thẻ'),'toàn bộ 137 thẻ đã lưu nằm trong Nhóm 15 (VA)');
 ok(E("PK.every(p=>grpOf(p)===15)||PK.some(p=>p.grp)"),'thẻ cũ không có nhóm → mặc định Nhóm 15 (VA)');
 C('fold',{g:'15'});ok(E('S.hf')===15&&E('PKID')==='g15'&&g.app().includes('Tất cả nhóm')&&g.app().includes('chạm để học theo nguyên tố'),'mở thư mục nhóm 15: thấy các nguyên tố');
 C('fold_back');ok(E('S.hf')===null&&E('PKID')==='all','quay lại danh sách thư mục');
 C('fold',{g:'16'});ok(E('S.v')==='home'&&E('S.hf')===16&&g.app().includes('chưa có tài liệu')&&g.app().includes('Chọn tệp'),'bấm nhóm trống → vẫn vào được, có sẵn nút Chọn tệp');
 for(const t of ['t_study','t_quiz','t_stats','t_know','t_list']){C(t);const a=g.app();ok(E('eq.length')===0&&E('C.length')===0&&a.includes('chưa có tài liệu')&&!/N2H4|NaN3|data-act="qstart"|data-act="rate"/.test(a),'nhóm trống, tab '+t+': hoàn toàn trống, không lộ phương trình nhóm 15');}
 C('t_home');
 ok(!g.app().includes('NaN'),'nhóm trống không lỗi hiển thị');
 await E("imRun('F2 + H2\\t2HF\\nCl2 + H2\\t2HCl','x.tsv')");ok(E('S.ai.items.length')===2,'nhóm trống: đọc 2 thẻ');
 C('fold_back');C('fold',{g:'17'});await E("imRun('F2 + H2\\t2HF\\nCl2 + H2\\t2HCl','x.tsv')");await E("MG.im_go()");await waitFor(()=>store.d.has('packs/x-g17'),'nhóm 17 tự được tạo khi nhập');
 ok(store.d.get('packs/x-g17').grp===17&&store.d.get('packs/x-g17').cards.length===2&&E('packsOf(17).length')===1&&E('S.v')==='home'&&!g.app().includes('chưa có tài liệu'),'nhóm trống: nhập tệp → tự tạo nhóm 17 + 2 thẻ, vào xem được ngay');
 C('fold_back');C('fold',{g:'15'});C('t_home');
 ok(!/Đấu trường|Săn Orb|Gacha|Slime|Boss|Cách chơi|mẹo/i.test(g.app()),'trang chính không còn game, cách chơi, mẹo');
 ok(g.app().includes('Chạm vào một huy hiệu')&&g.app().includes('data-act="bdg"'),'có dòng hướng dẫn nhỏ cho huy hiệu');
 C('bdg',{i:'0'});ok(E('S.bdi')===0&&g.app().includes('Khởi động')&&g.app().includes('10 lượt ôn')&&/chưa đạt|đã đạt/.test(g.app()),'chạm huy hiệu → hiện điều kiện + trạng thái');
 C('bdg',{i:'0'});ok(E('S.bdi')===null&&g.app().includes('Chạm vào một huy hiệu'),'chạm lại → ẩn');
 ok(E("BG.every(b=>!/gacha|slime|boss|Đấu trường/i.test(b[1]+b[2]))"),'huy hiệu không còn liên quan đến game');
 ok(E("tabsFor().length")===5&&E("typeof hunt")==='undefined'&&E("typeof arena")==='undefined'&&E("typeof pull")==='undefined','đã gỡ hết mã game');
 ok(g.els['#orbs'].textContent.includes('🔮'),'vẫn hiện số orb');
 const o0=E('M.orb');C('t_study');C('sc',{v:'all'});for(let i=0;i<4;i++){C('flip');C('r_good')}ok(E('M.orb')===o0+1,'hệ thống orb: 4 lần nhớ đúng → +1 orb');
 E("M.dq=null;dqd()");C('claim',{i:'ci'});ok(E('M.orb')===o0+1+3,'nhiệm vụ điểm danh vẫn tặng orb');
 E("M.orb=0;M.bd=[];A[day(0)]=10;chkBadge()");ok(E('M.orb')>=3&&E('M.bd.length')>=1,'huy hiệu mới vẫn tặng orb');
 const nb=O.ev("PK.length");fill(O,{npg:'16',npn:'Nhóm 16',nps:'Gr16b',npu:'x',npe:'Ts:Tenness:117;Og:Oganesson:118;Mc:Moscovi:115;Lv:Livermori:116;Fl:Flerovi:114'});O.ev("S.f.npg='16'");await O.ev('MG.m_newpack()');await waitFor(()=>store.d.has('packs/x-gr16b'),'tạo nhóm 16');ok(store.d.get('packs/x-gr16b').grp===16,'nhóm mới lưu đúng thư mục (16)');
 await waitFor(()=>g.ev("packsOf(16).length")===1,'thư mục 16 nhận nhóm mới');g.click('fold_back');ok(g.ev('S.v')==='folders'&&g.app().includes('Nhóm 16 (VIA)'),'thư mục 16 hiển thị');
 g.click('fold',{g:'16'});ok(g.ev('PKID')==='x-gr16b'&&g.ev('S.hf')===16,'mở thư mục 16');}
console.log('⑨ Hai ngôn ngữ (Tiếng Việt / English)');
{const g=client({store,who:{id:'u_t',level:'owner',name:'Cô Lan'},ls:new Map()});await unlock(g);
 ok(g.ev('LANG')==='vi'&&g.app().includes('Các nhóm nguyên tố'),'mặc định tiếng Việt (trang thư mục)');g.click('fold',{g:'15'});ok(g.app().includes('Ôn hôm nay'),'vào nhóm 15 thấy nút Ôn hôm nay');
 g.click('lang');ok(g.ev('LANG')==='en'&&g.mem.get('ez_lang')==='en','bấm 🌐: chuyển sang English và nhớ lựa chọn');
 ok(g.app().includes('Review today')&&g.app().includes('Badges')&&g.app().includes('Add materials')&&!g.app().includes('Ôn hôm nay')&&!g.app().includes('Huy hiệu'),'trang nhóm hiển thị tiếng Anh');
 g.click('fold_back');ok(g.app().includes('Element groups')&&g.app().includes('Group 15 (VA)')&&g.app().includes('Empty · tap to add materials'),'thư mục nhóm: Group 15 (VA), nhóm trống ghi Empty · tap to add materials');g.click('fold',{g:'15'});
 ok(g.app().includes('Tap a badge to see how to earn it'),'gợi ý huy hiệu bằng tiếng Anh');
 g.click('t_manage');ok(g.app().includes('Settings')&&g.app().includes('Flashcard'),'Quản lý bằng tiếng Anh');
 g.click('fold',{g:'15'});g.click('t_study');g.click('sc',{v:'all'});const card=g.ev("S.ord[0].f");ok(g.app().replace(/<[^>]*>/g,'').includes(card.slice(0,10)),'nội dung thẻ giữ nguyên (không bị dịch lẫn)');
 g.ev("toast('Đã lưu thẻ')");ok(g.els['#toast'].textContent==='Card saved','thông báo nhanh được dịch');
 g.click('lang');ok(g.ev('LANG')==='vi'&&g.app().includes('Ôn hôm nay')||g.ev('S.v')==='study','chuyển lại tiếng Việt');
 const g2=client({store,who:{id:'u_t',level:'owner',name:'Cô Lan'},ls:g.mem});await waitFor(()=>g2.ev('S.v')==='gate','gate');ok(g2.ev('LANG')==='vi','nhớ ngôn ngữ giữa các lần mở');}
console.log('⑩ Nâng cấp: cửa hàng orb, đóng băng chuỗi, tổng kết lượt ôn, sao lưu tệp');
{const g=client({store,who:{id:'u_t',level:'owner',name:'Cô Lan'},ls:new Map()});await unlock(g);g.click('fold',{g:'15'});const E=g.ev,C=g.click;
 ok(g.app().includes('Cửa hàng orb')&&g.app().includes('Đóng băng chuỗi'),'trang chính có cửa hàng orb');
 E('M.orb=10');C('buy',{i:'th:forest'});ok(!E("M.un.includes('forest')")&&E('M.orb')===10,'không đủ orb thì không mua được');
 E('M.orb=100');C('buy',{i:'th:forest'});ok(E("M.un.includes('forest')")&&E('M.orb')===70,'mua giao diện: trừ 30 orb');C('buy',{i:'th:forest'});ok(E('M.orb')===70,'không mua lại món đã có');
 C('ac',{v:'forest'});ok(E('ACC')==='forest'&&g.mem.get('T:g15c')==='"forest"','dùng giao diện đã mua');
 E('M.orb=200');C('buy',{i:'fz'});C('buy',{i:'fz'});C('buy',{i:'fz'});ok(E('M.fz')===2&&E('M.orb')===120,'đóng băng chuỗi: mua tối đa 2 (không trừ orb lần thứ 3)');
 E("M.fz=1;M.streak=5;M.last=day(2)");ok(E('streakNow()')===5,'bỏ lỡ 1 ngày + có đóng băng: chuỗi vẫn hiển thị');E('touch()');ok(E('M.streak')===6&&E('M.fz')===0,'quay lại: dùng 1 lượt đóng băng, chuỗi +1');
 E("M.fz=0;M.streak=5;M.last=day(2)");ok(E('streakNow()')===0,'không có đóng băng: chuỗi về 0');E('touch()');ok(E('M.streak')===1,'chuỗi bắt đầu lại');
 E("M.fz=1;M.streak=5;M.last=day(3)");E('touch()');ok(E('M.streak')===1&&E('M.fz')===1,'bỏ lỡ 2 ngày thì đóng băng không đủ');
 C('t_study');C('sc',{v:'all'});C('r_good');C('r_hard');C('r_again');ok(E('S.ss.g')===1&&E('S.ss.h')===1&&E('S.ss.a')===1,'ghi nhận kết quả lượt ôn');E('S.fin=true');C('t_study');ok(g.app().includes('Hoàn thành')&&g.app().includes('Thời gian')&&g.app().includes('XP'),'màn tổng kết lượt ôn');
 g.click('lang');ok(g.app().includes('Time')&&g.app().includes('Got it'),'tổng kết bằng tiếng Anh');g.click('lang');
 await g.ev("MG.bkfile()");const pf=JSON.parse(g.saved[g.saved.length-1].data.replace(/^﻿/,''));ok(pf.app==='EZChem'&&pf.kind==='progress'&&pf.M&&pf.P,'tải tệp sao lưu tiến độ');
 const xp=E('M.xp');E('M.xp=1;P={}');const ch=g.listeners.change;ok(typeof ch==='function','có bộ xử lý chọn tệp');
 ch({target:{id:'pbf',dataset:{},files:[{text:async()=>JSON.stringify(pf)}]}});await sleep(40);ok(E('M.xp')===xp&&E('M.un.includes("forest")')&&Object.keys(E('P')).length>0,'khôi phục tiến độ từ tệp (giữ cả vật phẩm đã mua)');
 ch({target:{id:'pbf',dataset:{},files:[{text:async()=>'{"bad":1}'}]}});await sleep(40);ok(E('M.xp')===xp&&E('S.note.ok')===0,'tệp sai định dạng bị từ chối, không mất dữ liệu');}
console.log('⑪ Nâng cấp tối đa: thống kê, ghi chú cá nhân, CSV, AI giải thích');
{const g=client({store,who:{id:'u_t',level:'owner',name:'Cô Lan'},ls:new Map(),ai:()=>'Phản ứng oxi hóa khử, cần nhiệt độ.'});await unlock(g);const E=g.ev,C=g.click;
 C('fold',{g:'15'});C('t_stats');ok(g.app().includes('Thống kê học tập')&&g.app().includes('14 ngày gần nhất')&&g.app().includes('Xuất thẻ (CSV)'),'tab Thống kê hiển thị');
 C('t_study');C('sc',{v:'all'});C('r_again');C('t_stats');ok(g.app().includes('Thẻ hay quên nhất')&&g.app().includes('×1'),'thẻ vừa quên xuất hiện trong thống kê');
 g.click('lang');ok(g.app().includes('Study statistics')&&g.app().includes('Export cards (CSV)'),'Thống kê bằng English');g.click('lang');
 C('t_study');ok(g.app().includes('Ghi chú của tôi'),'có khung ghi chú dưới thẻ');
 C('nt_edit');E("S.f.nt='Nhớ: <b>nhiệt</b> & xúc tác'");C('nt_save');const id=E('S.ord[S.idx].id');ok(E('PN')[id]==='Nhớ: <b>nhiệt</b> & xúc tác'&&g.mem.get('T:g15nt'),'lưu ghi chú và nhớ lại');
 ok(g.app().includes('&lt;b&gt;nhiệt&lt;/b&gt; &amp; xúc tác'),'ghi chú được escape (không chèn HTML)');
 g.click('lang');ok(g.app().includes('Nhớ: ')&&g.app().includes('My notes'),'ghi chú của người dùng không bị dịch');g.click('lang');
 await g.ev("MG.csv()");const csv=g.saved[g.saved.length-1];ok(/\.csv$/.test(csv.filename)&&csv.data.includes('Ghi chú của tôi')&&csv.data.includes('xúc tác'),'xuất CSV có cột ghi chú');
 await g.ev("MG.bkfile()");const pf=JSON.parse(g.saved[g.saved.length-1].data.replace(/^﻿/,''));ok(pf.N&&pf.N[id],'tệp tiến độ gồm ghi chú');
 C('nt_edit');C('nt_del');ok(!E('PN')[id],'xóa ghi chú');
 if(E('CL.hasAI')){await E("MG.nt_ai()");ok((E('S.xp')||{})[id]&&g.app().includes('Lưu vào ghi chú'),'AI giải thích hiển thị');C('nt_aisave');ok(E('PN')[id]&&!E('S.xp')[id],'lưu lời giải thích AI thành ghi chú')}else ok(true,'(bỏ qua AI: máy chủ giả không bật sample)');}
console.log(`\n${fails?'✗':'✓'} ${checks-fails}/${checks} kiểm tra đạt · ${((Date.now()-T0)/1000).toFixed(1)}s`);process.exit(fails?1:0)})().catch(e=>{console.log('LỖI KHÔNG BẮT ĐƯỢC:',e&&e.stack||e);process.exit(2)});
