**v2.8 (Kiến thức):** tab Quản lý đổi thành 📖 Kiến thức (`know()`): liệt kê toàn bộ phương trình của nhóm theo nguyên tố, có lọc nguyên tố/loại phản ứng, tìm kiếm; Quản lý thẻ & sao lưu vào qua nút trong trang này (`S.v='manage'`). Kiểm thử: 161 mục.

**v2.8 (độc lập):** mở file rời (không có Claude) thì app tự dùng kho lưu trên thiết bị (`localDb()`, khóa localStorage `ezc_db`, cùng giao diện với `CL.db`, cờ `CL.local`) nên Quản lý, thêm thẻ, nhập tệp, sao lưu JSON đều chạy; trong Claude vẫn dùng db của Claude. Chế độ độc lập không có AI (chỉ đọc nhanh), tải tệp qua Blob. Kiểm thử: 155 mục.

**v2.8:** tự khóa mỗi khi thoát ra rồi vào lại (`visibilitychange` → `lockNow()`, không còn nhớ phiên; đang mở hộp chọn tệp thì miễn qua `PICK`); sau mật khẩu luôn vào trang thư mục (`S.v='folders'`, `folders_v()`); nhóm trống vẫn mở được (`emptyGroup()`); thêm tài liệu một bước ngay trong nhóm (`importPanel(g)` → `imFile/imRun/imAI` → `MG.im_go`), nhóm trống tự được tạo khi nhập (`ensureGroupPack`, id `x-g<số nhóm>`). Tab Quản lý → AI chỉ còn “AI viết giải thích”. Kiểm thử: 149 mục.

**v2.7:** thêm tab Thống kê, ghi chú cá nhân từng thẻ (khóa `g15nt`, nằm trong sao lưu), xuất CSV, nút AI giải thích thẻ. Kiểm thử: 132 mục.

# v2.6

Nâng cấp: **Cửa hàng orb** (hằng `SHOP`/`THEMES`: mở giao diện Đại dương/Rừng xanh/Hoàng hôn 30 orb, “Đóng băng chuỗi” 40 orb, tối đa 2, dùng tự động khi bỏ lỡ đúng 1 ngày – `streakNow()`/`touch()`); **tổng kết lượt ôn** (`S.ss`); **sao lưu tiến độ ra tệp JSON** (`bkfile`, nhập qua `#pbf`); **báo lỗi nhẹ nhàng** (window error → toast). Tiến độ lưu thêm `M.un` (giao diện đã mở) và `M.fz` (số lượt đóng băng). Kiểm thử: 132 kiểm tra.

# v2.5

Hoàn thiện ngôn ngữ: tự chọn Tiếng Việt/English theo trình duyệt lần đầu, nhớ lựa chọn; ghi chú trong thẻ có bản dịch ở `i18n/en_cards.json` (khóa = nguyên văn tiếng Việt của thẻ); lịch sử cập nhật có bản tiếng Anh. Giao diện responsive cho điện thoại (thanh trên gọn, thông báo nằm trên thanh điều hướng), máy tính bảng và máy tính (khung rộng hơn, thư mục 4 cột), vùng chạm ≥42px trên màn hình cảm ứng, viền focus cho bàn phím.

# v2.4

Đã **bỏ toàn bộ game** (săn orb, gacha, đấu boss) nhưng giữ hệ thống orb (kiếm từ ôn thẻ, nhiệm vụ, huy hiệu). Trang chính có **thư mục các nhóm nguyên tố** (nhóm 15 – VA chứa toàn bộ thẻ hiện có; các nhóm khác hiện “Sắp có”). **Hai ngôn ngữ**: bảng dịch ở `i18n/en.json` (cặp [tiếng Việt, English], build.py nhúng vào `/*@EN@*/`); mọi chuỗi giao diện tự dịch lúc hiển thị, nội dung thẻ do bạn nhập được giữ nguyên. Thêm chữ mới trên giao diện → thêm cặp dịch vào `i18n/en.json`. Kiểm thử: `node tests/smoke.js` (101 kiểm tra).

# ⚠️ v2.3 – BẢN CÁ NHÂN CÓ MẬT KHẨU

Từ v2.3 EZChem là bản **cá nhân** của giáo viên: **không còn đăng nhập, học sinh, lớp học, giao bài, đề thi, xếp hạng, thông báo**. Còn lại: flashcard, luyện tập, game (slime, boss, boss tuần), Quản lý (Flashcard, AI nhập thẻ, Cài đặt/sao lưu). Mọi phần mô tả đăng nhập/lớp học bên dưới là của v2.0–2.1 và đã bị gỡ. Bản gốc trước khi gỡ: template.v2.1 (xem lịch sử). Từ v2.3: **bỏ Kho tài liệu và Hồ sơ**; mở app phải nhập mật khẩu (băm PBKDF2-SHA256 310.000 vòng trong hằng `GATE` của template.html; muốn đổi mật khẩu thì sinh salt/băm mới, KHÔNG ghi mật khẩu rõ), tự khóa sau 30 phút, nút 🔒 để khóa ngay. Khi đăng: khai báo capabilities `sample`, `downloads`, `user` và `db` với rules `[{path:"",read:"view",write:"admin"},{path:"data/users/{self}",write:"interact"}]`. Kiểm thử: `node tests/smoke.js` (99 kiểm tra).

# EZChem – Nền tảng ôn tập Hóa vô cơ (flashcard + game + quản lý lớp)

Một trang web **một file** (`dist/index.html`) gồm:

- **Học tập:** thẻ lật, tự đánh giá Quên/Khó/Nhớ (ôn lặp lại ngắt quãng), tra cứu, gợi ý, đảo mặt thẻ.
- **Luyện tập:** trắc nghiệm, gõ đáp án, ghép cặp, 60 giây, thi thử.
- **Game:** Săn Orb → Gacha slime (20+ slime, 5 hệ theo nguyên tố) → Đấu trường 10 boss mỗi nhóm; luyện slime, nhiệm vụ ngày, huy hiệu.
- **Lớp học:** tài khoản học viên (tên đăng nhập + mật khẩu), thông báo, tài liệu (Markdown, đính kèm), bảng xếp hạng.
- **Bài tập & đề thi:** giáo viên giao bài có hạn nộp (học thẻ đến mức thuộc chắc, hoặc làm một đề thi), giao cho cả lớp hoặc từng lớp, theo dõi ai đúng hạn/nộp trễ/chưa làm; ngân hàng đề thi theo nhóm/nguyên tố có giới hạn thời gian, điểm đạt, số lần làm; xuất CSV.
- **Boss tuần:** mỗi tuần một boss mạnh (xoay theo nguyên tố, giáo viên có thể cố định hoặc tắt), thưởng 80 orb lần hạ đầu tiên trong tuần, bảng xếp hạng sát thương theo tuần.
- **Biệt danh & màu avatar** cho học viên (giáo viên có thể tắt chung hoặc chặn từng em).
- **Quản lý (giáo viên):** cơ sở dữ liệu học sinh (họ tên, lớp, SĐT, phụ huynh, ghi chú riêng), thêm/sửa/khóa/xóa học viên, đặt lại mật khẩu, xem tiến độ từng em, xuất CSV; thêm/sửa/ẩn thẻ; tạo **nhóm nguyên tố mới**; đăng tài liệu và thông báo.
- **Bắt buộc đăng nhập** (giáo viên và học sinh đều có tên đăng nhập + mật khẩu). Không còn chế độ khách; mở file thường (không có máy chủ) chỉ hiện màn hình khóa.

## Cấu trúc thư mục

```
template.html      Khung ứng dụng (HTML + CSS + JS), có chỗ __DATA__ để nhét dữ liệu
packs/gr15.json    Gói dữ liệu "Nhóm 15" (thẻ, nguyên tố, slime, boss, ảnh)
packs/_*.json      Gói bắt đầu bằng dấu _ sẽ bị bỏ qua khi dựng
build.py           Ghép template + packs → dist/index.html (có kiểm tra lỗi dữ liệu)
dist/index.html    Sản phẩm cuối: 1 file, mở bằng trình duyệt hoặc đăng lên Claude
tools/new_pack.py          Tạo gói mới từ CSV + danh sách nguyên tố
tools/flippables_to_csv.py Xuất thẻ từ cơ sở dữ liệu app Flippables ra CSV
tools/cards_template.csv   Mẫu CSV
tests/smoke.js     Kiểm thử tự động (mô phỏng máy chủ có quy tắc quyền, nhiều máy cùng lúc)
```

## Dựng và kiểm thử

```bash
python3 build.py          # → dist/index.html
node tests/smoke.js       # kiểm tra toàn bộ (đăng nhập, quyền, nội dung, game…)
```
Mỗi lần sửa `template.html` hoặc `packs/*.json`: dựng lại, chạy test, rồi đăng `dist/index.html`.

## Thêm một nhóm nguyên tố mới (ví dụ Nhóm 16)

**Cách A – ngay trên web (nhanh nhất):** đăng nhập giáo viên → *Quản lý → Flashcard → Tạo nhóm nguyên tố mới*
(nhập `O:Oxi:8;S:Lưu huỳnh:16;Se:Selen:34;Te:Telu:52;Po:Poloni:84`), rồi *Nhập hàng loạt* các thẻ (dán `mặt trước | mặt sau | nguồn | giải thích` hoặc chọn file CSV).
Slime và 10 boss được sinh tự động. Dữ liệu này lưu trên máy chủ của trang (không nằm trong thư mục dự án).

**Cách B – bằng file (dữ liệu nằm trong dự án, nên dùng lâu dài):**
```bash
# 1) (tuỳ chọn) lấy thẻ từ Flippables: copy thư mục app_flutter ra máy, rồi
python3 tools/flippables_to_csv.py flippables_database.sqlite --list
python3 tools/flippables_to_csv.py flippables_database.sqlite --deck HVCTH_Gr16 -o tools/cards_gr16.csv
# 2) tạo gói
python3 tools/new_pack.py --id g16 --short Gr16 --name "Nhóm 16" --sub "Hóa vô cơ · Nhóm 16 (O, S, Se, Te, Po)" \
   --order 2 --elements "O:Oxi:8;S:Lưu huỳnh:16;Se:Selen:34;Te:Telu:52;Po:Poloni:84" --cards tools/cards_gr16.csv
# 3) (tuỳ chọn) mở packs/g16.json đổi tên slime/boss, màu, sức mạnh
python3 build.py && node tests/smoke.js
```

### Định dạng gói dữ liệu (`packs/*.json`)
```jsonc
{ "id":"g16", "order":2, "short":"Gr16", "name":"Nhóm 16", "sub":"Hóa vô cơ · Nhóm 16", "item":"phương trình phản ứng",
  "bg":["H₂SO₄","SO₂"],                       // ký hiệu bay ở nền (tuỳ chọn)
  "elements":[{ "s":"O","n":"Oxi","num":8,"c":"#3b82f6","he":"Hệ Oxi","acc":"drop",   // acc: wind|flame|bubbles|star|crystal|drop|bolt|leaf|ring|flask
    "slimes":[{"id":"g16o1","n":"Slime Oxi Non","r":"C","p":12,"k":"lucky"}, …4 con: C,R,SR,SSR]  // k: fifty|double|shield|peek|skip|lucky|regen|hunter
  }],
  "bosses":[{"n":"Quái Non Oxi","e":"O","hp":60,"atk":12,"rw":20}, …10 boss, boss cuối là "Đại Đế"],
  "images":{"p11":"data:image/jpeg;base64,…"},   // ảnh dùng cho thẻ (m = tên ảnh)
  "cards":[{"id":"g16-001","t":"f","f":"H2S + O2","b":"S + H2O","h":"nguồn","e":"giải thích","m":""}] }  // t: f=thẻ, i=ghi chú
```
Quy tắc quan trọng (build.py sẽ báo lỗi nếu sai): **id thẻ và id slime không được trùng**; **ký hiệu nguyên tố không trùng giữa các gói**;
**không đổi id thẻ đã có** (tiến độ học viên gắn theo id). Thẻ thuộc nguyên tố nào được suy ra từ ký hiệu xuất hiện sớm nhất ở mặt trước.

## Tài khoản, quyền và nơi lưu dữ liệu

| Vai trò | Cách vào | Quyền |
|---|---|---|
| Giáo viên | Lần đầu: chủ trang mở trang → màn hình **Thiết lập** tạo tên đăng nhập + mật khẩu (≥10 ký tự, có chữ và số). Các lần sau: đăng nhập bằng tài khoản đó. Chỉ hoạt động khi trang được mở bằng tài khoản Claude của chủ trang/biên tập viên. | Quản lý tất cả |
| Học viên | Tên đăng nhập + mật khẩu do giáo viên tạo | Học, chơi, xem lớp; ghi tiến độ của chính mình |

Quên mật khẩu giáo viên: chủ trang mở trang → màn hình đăng nhập → “Quên mật khẩu giáo viên?” để đặt lại. Học viên quên mật khẩu: giáo viên bấm 🔑 ở tab Học viên.

Chia sẻ cho học viên: tab **Quản lý → Chia sẻ** trong ứng dụng có hướng dẫn từng bước và tin nhắn mẫu (Chia sẻ → mời bằng email → quyền “Người đóng góp”).

Quy tắc `db` khai báo khi đăng trang (máy chủ Claude thực thi, không phải mã trang):
```json
{"db":{"rules":[{"path":"","read":"view","write":"admin"},
                {"path":"reports","read":"view","write":"admin"},
                {"path":"reports/{self}","write":"interact"},
                {"path":"data/users/{self}","write":"interact"}]},
 "user":{"scopes":["profile"]},"downloads":true,"sample":{}}
```
Dữ liệu: `asg/<id>` (bài tập) · `exams/<id>` (đề thi) · `cfg/auth` (đã thiết lập giáo viên chưa) · `roster/<tên>` (tài khoản + băm mật khẩu; tài khoản giáo viên có `r:"t"`) · `data/users/<uid giáo viên>/prof_<tên>` (SĐT, phụ huynh, ghi chú: **chỉ giáo viên đọc được**) · `reports/<uid>` (báo cáo cho giáo viên + bảng xếp hạng) · `data/users/<uid>/st_<tên>` (toàn bộ tiến độ, **riêng tư**, đồng bộ nhiều thiết bị) · `packs/<id>` (nhóm do giáo viên tạo) · `cfg/patches` (sửa/ẩn/thêm thẻ của gói mặc định) · `cfg/settings` · `docs/*` · `ann/*`.

### Bảo mật đang bật
- Bắt buộc đăng nhập cho mọi vai trò; không có chế độ khách.
- Mật khẩu: PBKDF2-SHA256, **310.000 vòng**, muối riêng; tài khoản cũ (132.000 vòng) vẫn đăng nhập được, giáo viên được nâng cấp tự động khi đăng nhập. Mật khẩu tự tạo dài 10 ký tự.
- Khóa tạm khi sai nhiều lần (5 lần → 30 giây, tăng gấp đôi tới 15 phút), lưu trong trình duyệt nên tải lại trang không xóa được.
- Tự đăng xuất: giáo viên 20 phút, học viên 60 phút không hoạt động; phiên học viên hết hạn sau 12 giờ; giáo viên luôn phải nhập mật khẩu khi mở trang. Đăng xuất xóa dữ liệu lớp khỏi bộ nhớ trang.
- Học viên không ghi được vào danh sách lớp, cấu hình xác thực, nội dung, hay dữ liệu bạn khác (quy tắc `db`, máy chủ Claude thực thi).

### Giới hạn bảo mật (nên đọc)
- Việc kiểm tra mật khẩu diễn ra **trong trình duyệt**, và học viên đọc được bản băm của lớp → bảo vệ **mức lớp học**, không phải mức ngân hàng. Dùng mật khẩu ngẫu nhiên do hệ thống tạo, chỉ mời đúng học viên bằng email, không bật chia sẻ công khai.
- Học viên cần **tài khoản Claude** (miễn phí) và được mời bằng email thì mới mở được trang. Nếu muốn học viên vào chỉ bằng liên kết, không cần Claude, phải chuyển sang máy chủ riêng (Firebase/Supabase…).
- Báo cáo XP do trình duyệt học viên gửi nên có thể bị chỉnh bởi người rành kỹ thuật; đừng dùng bảng xếp hạng cho điểm chính thức.
- Hồ sơ học sinh (SĐT, ghi chú) nằm trong kho riêng của **một** tài khoản Claude (người đã nhập); biên tập viên khác không thấy.

## Tính năng mới (v2.0)
- **Hồ sơ học sinh/giáo viên:** tab *Hồ sơ* (cấp, XP, chuỗi ngày, huy hiệu, 7 ngày qua, đổi ảnh đại diện); khung tên + ảnh nhỏ và nút 🚪 đăng xuất luôn có ở đầu trang.
- **Màn hình đăng nhập** có hai mục Học sinh / Giáo viên; học sinh không thấy bất kỳ mục quản lý nào.
- **Cân bằng game:** boss yếu nhất (200 HP) cần ≥10 câu đúng kể cả khi đội mạnh nhất (sát thương tối đa 20/đòn ở màn 1, tăng dần theo màn); phản công mạnh hơn. Săn orb giảm khoảng 70%, ôn thẻ tặng 1 orb mỗi 4 lần đúng. Trắc nghiệm 4 đáp án dùng đáp án nhiễu "gần đúng" (đổi hệ số, chỉ số, nguyên tố cùng nhóm, thêm/bớt chất…).
- **AI cho giáo viên** (tab *Quản lý → AI*, dùng capability `sample` nên cần khai báo `"sample":{}` khi đăng):
  nhập thẻ từ Anki/Quizlet/Flippables/CSV/JSON/HTML; viết giải thích cho thẻ; nhận xét tình hình lớp + soạn thông báo. Mọi kết quả đều xem trước rồi mới ghi.
- **Cần chú ý** (tab Học viên): học viên lâu không học hoặc ôn nhiều mà thuộc ít.
- **Sao lưu/khôi phục** dữ liệu lớp bằng JSON (Quản lý → Cài đặt).

## Nhập từ phần mềm flashcard
Trong app: *Quản lý → AI → Nhập thẻ* (dán/ chọn tệp TXT, CSV, TSV, JSON, HTML). Với tệp nhị phân (`.apkg`, `.colpkg`, `.sqlite`) hãy đưa cho Claude trong cuộc trò chuyện hoặc tự chạy:
```bash
python3 tools/import_any.py bo-the.apkg --list
python3 tools/import_any.py bo-the.apkg --deck "Hóa 11" -o tools/cards_new.csv
python3 tools/new_pack.py --id g16 --short Gr16 --name "Nhóm 16" --order 2 --elements "O:Oxi:8;S:Lưu huỳnh:16" --cards tools/cards_new.csv
python3 build.py && node tests/smoke.js
```

## Cập nhật ứng dụng qua Claude (kể cả sau khi đóng gói)
`CLAUDE.md` mô tả cách Claude làm việc với dự án. Mở cuộc trò chuyện mới, đính kèm file zip dự án và nói điều bạn muốn; Claude sửa mã, chạy kiểm thử và đăng lại **lên cùng liên kết** nên dữ liệu lớp được giữ. Muốn chuyển sang liên kết/ứng dụng khác: tải bản sao lưu JSON trước, rồi khôi phục ở nơi mới.

## Giới hạn kỹ thuật đã biết
- Mỗi nhóm do giáo viên tạo nằm trong **một tài liệu ≤ 256 KB** (khoảng 1.500 thẻ chữ); nhóm lớn hơn nên đưa vào `packs/*.json` (Cách B).
- Tổng tối đa 25.000 bản ghi trong cơ sở dữ liệu của trang.
- Đính kèm tệp vào tài liệu cần bật tính năng `assets` khi đăng (làm trang chỉ dùng được trong tổ chức, không chia sẻ công khai).
- Dữ liệu tiến độ xóa theo từng trình duyệt nếu học viên không đăng nhập hoặc chỉ có quyền xem; mã sao lưu trong trang chính vẫn dùng được.

## Tiếp tục phát triển cùng Claude
Mở cuộc trò chuyện mới, **đính kèm file zip dự án này** và nói rõ việc cần làm, ví dụ:
- “Thêm nhóm 16: đây là file CSV thẻ [đính kèm]; tạo gói, dựng lại và đăng.”
- “Thêm chế độ giao bài cho từng lớp có hạn nộp.”
- “Đổi bảng xếp hạng thành theo tuần.”
Claude sẽ đọc `README.md`, sửa `template.html`/`packs`, chạy `build.py` + `tests/smoke.js`, rồi đăng `dist/index.html`.

## Gợi ý lộ trình
báo cáo PDF cho phụ huynh · thông báo nhắc ôn hằng ngày · nhiều lớp/nhiều giáo viên · tách `template.html` thành các module nhỏ khi file quá lớn.
