#!/usr/bin/env python3
"""Chuyển dữ liệu từ nhiều phần mềm flashcard sang CSV của EZChem (front,back,hint,explanation,type).
Hỗ trợ:
  .apkg / .colpkg   Anki (gói xuất có lịch sử học tập hoặc không)   [bản Anki mới nén .anki21b: xuất lại "Notes in Plain Text"]
  .txt / .tsv       Anki "Notes in Plain Text", Quizlet (xuất văn bản), Memrise, Cram…
  .csv              Google Sheets, Excel, Quizlet…
  .json             danh sách {front,back,...} hoặc {"cards":[...]}
  .sqlite / .db     Flippables (chuyển sang flippables_to_csv.py) hoặc cơ sở dữ liệu Anki đã giải nén
Dùng:
  python3 tools/import_any.py file.apkg --list                  # xem các bộ thẻ (chỉ Anki .apkg)
  python3 tools/import_any.py file.apkg --deck "Hóa 11" -o tools/cards_new.csv
  python3 tools/import_any.py quizlet.txt -o tools/cards_new.csv
Sau đó: python3 tools/new_pack.py ... --cards tools/cards_new.csv   (xem README)"""
import argparse, csv, html, io, json, os, re, sqlite3, subprocess, sys, tempfile, zipfile

def clean(x):
    x = '' if x is None else str(x)
    x = re.sub(r'<br\s*/?>', ' ', x, flags=re.I)
    x = re.sub(r'</(div|p|li)>', ' ', x, flags=re.I)
    x = re.sub(r'<sub>(.*?)</sub>', r'\1', x, flags=re.I | re.S)
    x = re.sub(r'<sup>(.*?)</sup>', r'^\1', x, flags=re.I | re.S)
    x = re.sub(r'\[sound:[^\]]*\]', '', x)
    x = re.sub(r'<[^>]+>', '', x)
    return re.sub(r'\s+', ' ', html.unescape(x)).strip()

KEYS = {'f': ['f','front','question','term','q','mặt trước'], 'b': ['b','back','answer','definition','a','mặt sau'],
        'h': ['h','hint','source','nguồn'], 'e': ['e','explanation','note','notes','giải thích']}

def from_json(text):
    j = json.loads(text.lstrip('﻿'))
    if isinstance(j, dict):
        for k in ('cards', 'notes', 'items', 'data'):
            if isinstance(j.get(k), list): j = j[k]; break
    out = []
    for o in j:
        if isinstance(o, list): r = [clean(v) for v in (o + ['', '', '', ''])[:4]]
        else:
            low = {k.lower(): v for k, v in o.items()}
            r = [clean(next((low[k] for k in KEYS[c] if low.get(k) not in (None, '')), '')) for c in 'fbhe']
        out.append(r)
    return out

def from_text(text):
    text = text.lstrip('﻿')
    lines = [l for l in text.splitlines() if l.strip() and not l.lstrip().startswith('#')]
    if not lines: return []
    tabs = sum('\t' in l for l in lines) >= len(lines) * .6
    rows = list(csv.reader(lines, delimiter='\t' if tabs else ('|' if sum('|' in l for l in lines) >= len(lines) * .6 else ',')))
    if rows and re.search(r'front|back|question|answer|term|definition|mặt', ' '.join(rows[0][:2]), re.I): rows.pop(0)
    return [[clean(v) for v in (r + ['', '', '', ''])[:4]] for r in rows]

def anki_db(path, deck, listing):
    c = sqlite3.connect(path)
    decks = {}
    try:
        col = c.execute('select decks from col').fetchone()
        decks = {int(k): v['name'] for k, v in json.loads(col[0]).items()}
    except Exception:
        try: decks = {r[0]: r[1] for r in c.execute('select id,name from decks')}
        except Exception: pass
    if listing:
        for i, n in decks.items():
            k = c.execute('select count(distinct nid) from cards where did=?', (i,)).fetchone()[0]
            print(f'{n}\t{k} ghi chú')
        return None
    if deck:
        ids = [i for i, n in decks.items() if n == deck]
        if not ids: sys.exit(f'Không thấy bộ "{deck}". Dùng --list để xem tên.')
        q = 'select n.flds from notes n where n.id in (select nid from cards where did=?) order by n.id'
        rows = c.execute(q, (ids[0],)).fetchall()
    else:
        rows = c.execute('select flds from notes order by id').fetchall()
    return [[clean(v) for v in (r[0].split('\x1f') + ['', '', '', ''])[:4]] for r in rows]

def main():
    a = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    a.add_argument('file'); a.add_argument('--list', action='store_true'); a.add_argument('--deck'); a.add_argument('-o', '--out', default='cards.csv')
    g = a.parse_args(); ext = os.path.splitext(g.file)[1].lower(); rows = None
    if ext in ('.apkg', '.colpkg'):
        with zipfile.ZipFile(g.file) as z, tempfile.TemporaryDirectory() as t:
            names = z.namelist()
            n = next((x for x in ('collection.anki21', 'collection.anki2') if x in names), None)
            if not n:
                sys.exit('Gói này dùng định dạng Anki mới (collection.anki21b, nén zstd). Trong Anki hãy chọn Xuất → "Notes in Plain Text" rồi chạy lại với file .txt.')
            z.extract(n, t); rows = anki_db(os.path.join(t, n), g.deck, g.list)
    elif ext in ('.sqlite', '.db', '.anki2', '.anki21'):
        c = sqlite3.connect(g.file); tb = {r[0] for r in c.execute("select name from sqlite_master where type='table'")}; c.close()
        if 'flashcards' in tb and 'decks' in tb:
            cmd = [sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'flippables_to_csv.py'), g.file, '-o', g.out]
            if g.list: cmd.append('--list')
            if g.deck: cmd += ['--deck', g.deck]
            sys.exit(subprocess.call(cmd))
        rows = anki_db(g.file, g.deck, g.list)
    elif ext == '.json': rows = from_json(open(g.file, encoding='utf-8').read())
    else: rows = from_text(open(g.file, encoding='utf-8-sig', errors='replace').read())
    if rows is None: return
    rows = [r for r in rows if r[0]]
    with open(g.out, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.writer(fh); w.writerow(['front', 'back', 'hint', 'explanation', 'type'])
        for f, b, h, e in rows: w.writerow([f, b, h, e, '' if b else 'note'])
    print(f'✓ {len(rows)} thẻ → {g.out}')

if __name__ == '__main__': main()
