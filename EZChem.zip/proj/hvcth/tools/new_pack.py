#!/usr/bin/env python3
"""Tạo gói dữ liệu mới (thêm một nhóm nguyên tố) từ file CSV các thẻ.
Ví dụ (nhóm 16):
  python3 tools/new_pack.py --id g16 --short Gr16 --name "Nhóm 16" \
      --sub "Hóa vô cơ · Nhóm 16 (O, S, Se, Te, Po)" --order 2 \
      --elements "O:Oxi:8;S:Lưu huỳnh:16;Se:Selen:34;Te:Telu:52;Po:Poloni:84" \
      --cards tools/cards_gr16.csv
CSV (UTF-8, dòng đầu là tiêu đề): front,back,hint,explanation,type
  - front: chất phản ứng  - back: sản phẩm  - hint: nguồn sách (tuỳ chọn)  - explanation: giải thích (tuỳ chọn)
  - type: để trống = thẻ thường; "note" = thẻ ghi chú (không có mặt sau)
Slime và boss được sinh tự động bằng tên mẫu; mở file JSON để đổi tên/màu/sức mạnh theo ý bạn."""
import argparse, csv, json, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PALETTE = ['#3b82f6','#f59e0b','#10b981','#ec4899','#8b5cf6','#06b6d4','#ef4444','#84cc16','#f97316','#14b8a6','#a855f7','#eab308']
ACCS = ['wind','flame','bubbles','star','crystal','drop','bolt','leaf','ring','flask']
SK = {'C':['lucky','skip','peek'],'R':['fifty','shield','peek','lucky'],'SR':['double','regen','fifty','shield','peek'],'SSR':['hunter','double','regen']}
BASE = {'C':12,'R':36,'SR':68,'SSR':120}
NAMES = {'C':'Slime {n} Non','R':'Slime {n} Chiến Binh','SR':'Slime {n} Tinh Anh','SSR':'Slime {n} Chúa Tể'}
BOSS_T = ['Quái Non','Bóng Ma','Tiểu Quỷ','Hiệp Sĩ','Pháp Sư','Rồng','Ma Vương','Chúa Tể','Thống Lĩnh']
HP = [200,288,382,480,582,690,802,920,1042,1752]; ATK = [15,18,22,25,29,32,36,39,43,55]; RW = [20,28,36,48,60,75,90,110,130,200]  # app tự nâng boss lên mức tối thiểu này nếu số liệu thấp hơn

def main():
    a = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    a.add_argument('--id', required=True); a.add_argument('--short', required=True); a.add_argument('--name', required=True)
    a.add_argument('--sub', default=''); a.add_argument('--item', default='phương trình phản ứng'); a.add_argument('--order', type=int, default=50)
    a.add_argument('--elements', required=True, help='"Ký hiệu:Tên:Số hiệu;..."'); a.add_argument('--cards', required=True)
    a.add_argument('--out', default=None)
    g = a.parse_args()
    els = []
    for i, part in enumerate(g.elements.split(';')):
        s, n, num = [x.strip() for x in part.split(':')]
        slimes = []
        for j, r in enumerate(['C','R','SR','SSR']):
            slimes.append({'id': f'{g.id}{s.lower()}{j+1}', 'n': NAMES[r].format(n=n), 'r': r, 'p': BASE[r] + (i % 4) * 2 - 2, 'k': SK[r][(i + j) % len(SK[r])]})
        els.append({'s': s, 'n': n, 'num': int(num), 'c': PALETTE[i % len(PALETTE)], 'he': f'Hệ {n}', 'acc': ACCS[i % len(ACCS)], 'slimes': slimes})
    cards = []
    with open(g.cards, encoding='utf-8-sig', newline='') as fh:
        for r in csv.DictReader(fh):
            f = (r.get('front') or '').strip()
            if not f: continue
            note = (r.get('type') or '').strip().lower() == 'note'
            cards.append({'id': f'{g.id}-{len(cards)+1:03d}', 't': 'i' if note else 'f', 'f': f, 'b': (r.get('back') or '').strip(), 'h': (r.get('hint') or '').strip(), 'e': (r.get('explanation') or '').strip(), 'm': ''})
    bosses = []
    for i in range(10):
        e = els[i % len(els)]
        bosses.append({'n': f'Đại Đế {g.name}' if i == 9 else f'{BOSS_T[i]} {e["n"]}', 'e': e['s'], 'hp': HP[i], 'atk': ATK[i], 'rw': RW[i]})
    pack = {'id': g.id, 'order': g.order, 'short': g.short, 'name': g.name, 'sub': g.sub or g.name, 'item': g.item,
            'bg': [], 'elements': els, 'bosses': bosses, 'images': {}, 'cards': cards}
    out = g.out or os.path.join(ROOT, 'packs', f'{g.id}.json')
    json.dump(pack, open(out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'✓ Đã tạo {out}: {len(cards)} thẻ, {len(els)} nguyên tố, {len(els)*4} slime, 10 boss.')
    print('  Bước tiếp: mở file để đổi tên slime/boss nếu muốn, rồi chạy  python3 build.py')

if __name__ == '__main__':
    main()
