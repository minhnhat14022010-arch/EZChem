#!/usr/bin/env python3
"""Xuất thẻ từ cơ sở dữ liệu Flippables (flippables_database.sqlite) ra CSV để đưa vào new_pack.py.
Lấy file sqlite: copy thư mục /data/data/dev.skstudios.flippables/app_flutter từ giả lập (xem README).
Dùng:
  python3 tools/flippables_to_csv.py flippables_database.sqlite --list            # xem các bộ thẻ
  python3 tools/flippables_to_csv.py flippables_database.sqlite --deck EZChem_Gr16 -o tools/cards_gr16.csv"""
import argparse, csv, json, sqlite3, sys

def ops(s):
    if not s: return []
    j = json.loads(s)
    q = j['richText']['quillJson'] if 'richText' in j else j['quillJson']
    return json.loads(q)

def text(s):
    return ''.join(o['insert'] for o in ops(s) if isinstance(o['insert'], str)).strip()

def main():
    a = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    a.add_argument('db'); a.add_argument('--list', action='store_true'); a.add_argument('--deck'); a.add_argument('-o', '--out', default='cards.csv')
    g = a.parse_args()
    c = sqlite3.connect(g.db)
    decks = c.execute('select d.id,d.name,(select count(*) from flashcards f where f.deck_id=d.id) from decks d').fetchall()
    if g.list or not g.deck:
        for _, n, k in decks: print(f'{n}\t{k} thẻ')
        return
    ids = [d[0] for d in decks if d[1] == g.deck]
    if not ids: sys.exit(f'Không thấy bộ thẻ "{g.deck}". Dùng --list để xem tên.')
    rows = c.execute('select type,front_side,back_side,hint,explanation from flashcards where deck_id=? order by created_at,rowid', (ids[0],)).fetchall()
    with open(g.out, 'w', encoding='utf-8-sig', newline='') as fh:
        w = csv.writer(fh); w.writerow(['front', 'back', 'hint', 'explanation', 'type'])
        for typ, fr, bk, h, ex in rows:
            w.writerow([text(fr), text(bk) if typ == 'flashcard' else '', text(h), text(ex), 'note' if typ == 'information' else ''])
    print(f'✓ Đã ghi {len(rows)} thẻ vào {g.out}. Lưu ý: thẻ có ảnh sẽ chưa mang ảnh theo (thêm thủ công vào "images" trong gói nếu cần).')

if __name__ == '__main__':
    main()
